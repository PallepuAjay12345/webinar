// const bar = document.getElementById('bar')
// const nav = document.getElementById('navbar')


// if(bar)
//     {
//         bar.addEventListener('click' , () =>
//         {
//             nav.classList.add('active');
//         })
//     }





// document.addEventListener('DOMContentLoaded', () => {
//     const navbarToggle = document.getElementById('navbarToggle');
//     const navbarLinks = document.getElementById('navbar');

//     navbarToggle.addEventListener('click', () => {
//         navbarLinks.classList.toggle('active')
//     });
// });


// <script>
 
// const button = document.getElementById('myButton');
// const nav = document.getElementById('navbar');



// if(bar)
//     {
//         nav.addEventListener('click' , () =>
//         {
//             nav.classList.add('active');
//         })
//     }
// </script>









